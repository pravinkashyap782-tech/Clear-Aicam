# ClearCam AI — Android Studio project

## Build an installable APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this `ClearCamAI-Android` folder in Android Studio.
3. Allow Gradle sync to finish (internet is needed for the first dependency download).
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the APK location; normally `app/build/outputs/apk/debug/app-debug.apk`.
7. Copy the APK to your phone and install it. If prompted, allow installing apps from that source.

## Current implementation
- Native Kotlin + Jetpack Compose interface.
- CameraX live camera preview and photo capture.
- Front/back camera switching.
- Basic blur estimate and local sharpening/brightness/contrast enhancement.
- Before/after preview.
- Save enhanced image to `Pictures/ClearCamAI` in the phone gallery.

## Important limitation
This is a working starter implementation, not a finished AI restoration product. The current enhancement is traditional image processing, not a trained AI model. It does not yet perform dedicated face restoration or reliably recover detail from severely blurred photos. The project source is provided here; this environment does not have the Android SDK/Gradle toolchain needed to compile and verify an APK.
