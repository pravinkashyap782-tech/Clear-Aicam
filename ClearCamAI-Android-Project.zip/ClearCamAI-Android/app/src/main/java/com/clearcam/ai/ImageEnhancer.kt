package com.clearcam.ai

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Lightweight on-device enhancement prototype.
 * This is image processing, not a trained AI restoration model.
 */
object ImageEnhancer {
    fun enhance(source: Bitmap): Bitmap {
        val w = source.width
        val h = source.height
        val input = source.copy(Bitmap.Config.ARGB_8888, false)
        val output = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(w * h)
        input.getPixels(pixels, 0, w, 0, 0, w, h)

        // Mild contrast and brightness correction.
        for (i in pixels.indices) {
            val c = pixels[i]
            val r = channel((Color.red(c) - 128) * 1.12f + 128 + 5)
            val g = channel((Color.green(c) - 128) * 1.12f + 128 + 5)
            val b = channel((Color.blue(c) - 128) * 1.12f + 128 + 5)
            pixels[i] = Color.argb(Color.alpha(c), r, g, b)
        }

        // Gentle unsharp mask using a 4-neighbour blur approximation.
        val adjusted = pixels.clone()
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                val center = pixels[i]
                val neighbors = intArrayOf(pixels[i - 1], pixels[i + 1], pixels[i - w], pixels[i + w])
                val rr = neighbors.sumOf { Color.red(it) } / 4
                val gg = neighbors.sumOf { Color.green(it) } / 4
                val bb = neighbors.sumOf { Color.blue(it) } / 4
                val r = channel(Color.red(center) + (Color.red(center) - rr) * 0.35f)
                val g = channel(Color.green(center) + (Color.green(center) - gg) * 0.35f)
                val b = channel(Color.blue(center) + (Color.blue(center) - bb) * 0.35f)
                adjusted[i] = Color.rgb(r, g, b)
            }
        }
        output.setPixels(adjusted, 0, w, 0, 0, w, h)
        return output
    }

    /** Rough edge-strength estimate; it can flag soft images but is not a clinical/AI blur detector. */
    fun isLikelyBlurry(bitmap: Bitmap): Boolean {
        val sampleW = min(160, bitmap.width)
        val sampleH = min(160, bitmap.height)
        val small = Bitmap.createScaledBitmap(bitmap, sampleW, sampleH, true)
        val px = IntArray(sampleW * sampleH)
        small.getPixels(px, 0, sampleW, 0, 0, sampleW, sampleH)
        var total = 0.0
        var count = 0
        for (y in 1 until sampleH - 1) {
            for (x in 1 until sampleW - 1) {
                val i = y * sampleW + x
                fun gray(c: Int) = (Color.red(c) * 0.299 + Color.green(c) * 0.587 + Color.blue(c) * 0.114)
                val lap = 4 * gray(px[i]) - gray(px[i - 1]) - gray(px[i + 1]) - gray(px[i - sampleW]) - gray(px[i + sampleW])
                total += abs(lap)
                count++
            }
        }
        return count > 0 && total / count < 9.0
    }

    private fun channel(value: Float) = max(0, min(255, value.toInt()))
}
