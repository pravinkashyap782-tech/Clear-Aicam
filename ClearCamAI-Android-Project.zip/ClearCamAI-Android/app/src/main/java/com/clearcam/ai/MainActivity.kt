package com.clearcam.ai

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ClearCamScreen() }
    }
}

@Composable
private fun ClearCamScreen() {
    val context = LocalContext.current
    var hasPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        hasPermission = it
    }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var original by remember { mutableStateOf<Bitmap?>(null) }
    var enhanced by remember { mutableStateOf<Bitmap?>(null) }
    var message by remember { mutableStateOf("Ready to capture") }
    var useFront by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF58D6C7),
        background = Color(0xFF101820),
        surface = Color(0xFF1B2933)
    )) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF101820)) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("ClearCam AI", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                Text("Capture • Check blur • Enhance • Save", color = Color(0xFFB8C9D2))
                Spacer(Modifier.height(16.dp))

                if (hasPermission) {
                    CameraPreview(
                        modifier = Modifier.fillMaxWidth().height(390.dp),
                        front = useFront,
                        onReady = { imageCapture = it }
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = {
                            useFront = !useFront
                        }) { Text("Switch camera") }
                        Button(
                            enabled = imageCapture != null,
                            onClick = {
                                val capture = imageCapture ?: return@Button
                                val photoFile = File(context.cacheDir, "clearcam_${System.currentTimeMillis()}.jpg")
                                val options = ImageCapture.OutputFileOptions.Builder(photoFile).build()
                                capture.takePicture(options, ContextCompat.getMainExecutor(context),
                                    object : ImageCapture.OnImageSavedCallback {
                                        override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                                            val bitmap = BitmapFactory.decodeFile(photoFile.absolutePath)
                                            if (bitmap != null) {
                                                original = bitmap
                                                enhanced = ImageEnhancer.enhance(bitmap)
                                                val blur = ImageEnhancer.isLikelyBlurry(bitmap)
                                                message = if (blur) "Possible blur detected — enhancement applied. Retake for best results."
                                                else "Photo captured and enhancement applied."
                                            } else message = "Could not read captured photo."
                                        }
                                        override fun onError(exception: ImageCaptureException) {
                                            message = "Capture failed: ${exception.message}"
                                        }
                                    })
                            }
                        ) { Text("Capture photo") }
                    }
                } else {
                    Text("Camera permission is needed to take photos.", color = Color.White)
                    Button(onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }) {
                        Text("Allow camera")
                    }
                }

                Spacer(Modifier.height(12.dp))
                Text(message, color = Color(0xFF58D6C7))
                Spacer(Modifier.height(16.dp))

                if (original != null && enhanced != null) {
                    Text("Before", color = Color.White, style = MaterialTheme.typography.titleMedium)
                    Image(original!!.asImageBitmap(), null, Modifier.fillMaxWidth().heightIn(max = 260.dp))
                    Spacer(Modifier.height(8.dp))
                    Text("After — basic enhancement", color = Color.White, style = MaterialTheme.typography.titleMedium)
                    Image(enhanced!!.asImageBitmap(), null, Modifier.fillMaxWidth().heightIn(max = 260.dp))
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = {
                        val values = ContentValues().apply {
                            put(MediaStore.Images.Media.DISPLAY_NAME, "ClearCam_${System.currentTimeMillis()}.jpg")
                            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ClearCamAI")
                        }
                        val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                        if (uri != null) {
                            context.contentResolver.openOutputStream(uri)?.use { out ->
                                enhanced!!.compress(Bitmap.CompressFormat.JPEG, 95, out)
                            }
                            message = "Enhanced photo saved to Gallery / Pictures / ClearCamAI"
                        } else message = "Could not save photo."
                    }, modifier = Modifier.fillMaxWidth()) { Text("Save enhanced photo to Gallery") }
                }
                Spacer(Modifier.height(20.dp))
                Text(
                    "Note: This starter version uses on-device image sharpening/lighting adjustments and a basic blur estimate. It does not yet include a trained AI restoration or face-enhancement model.",
                    color = Color(0xFF9FB0BA),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun CameraPreview(
    modifier: Modifier,
    front: Boolean,
    onReady: (ImageCapture) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            val previewView = PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
            val providerFuture = ProcessCameraProvider.getInstance(ctx)
            providerFuture.addListener({
                val provider = providerFuture.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val capture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                val selector = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                try {
                    provider.unbindAll()
                    provider.bindToLifecycle(lifecycleOwner, selector, preview, capture)
                    onReady(capture)
                } catch (_: Exception) { }
            }, ContextCompat.getMainExecutor(ctx))
            previewView
        },
        update = { view ->
            val providerFuture = ProcessCameraProvider.getInstance(context)
            providerFuture.addListener({
                val provider = providerFuture.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(view.surfaceProvider) }
                val capture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
                val selector = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                try {
                    provider.unbindAll()
                    provider.bindToLifecycle(lifecycleOwner, selector, preview, capture)
                    onReady(capture)
                } catch (_: Exception) { }
            }, ContextCompat.getMainExecutor(context))
        }
    )
}
